#import <Cocoa/Cocoa.h>

@interface EqualizerDelegateExample : NSObject {
	double values[10];
}
@end
