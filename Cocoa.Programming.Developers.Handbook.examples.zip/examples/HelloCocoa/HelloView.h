#import <Cocoa/Cocoa.h>


@interface HelloView : NSView {

}

@end
