#import <Cocoa/Cocoa.h>

@interface ContextMenuView : NSView {}
@end
