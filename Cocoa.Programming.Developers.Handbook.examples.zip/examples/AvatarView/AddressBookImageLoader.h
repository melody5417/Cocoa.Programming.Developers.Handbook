#import <Cocoa/Cocoa.h>

@interface AddressBookImageLoader : NSObject {
	IBOutlet NSTableView *view;
	IBOutlet NSMutableArray  *images;
}
@end
