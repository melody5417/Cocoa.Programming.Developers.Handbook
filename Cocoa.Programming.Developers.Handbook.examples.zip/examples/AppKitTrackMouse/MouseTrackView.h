#import <Cocoa/Cocoa.h>


@interface MouseTrackView : NSView {
	NSBezierPath *path;
}

@end
