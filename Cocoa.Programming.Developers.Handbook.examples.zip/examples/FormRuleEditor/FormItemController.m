#import "FormItemController.h"

@implementation FormItemController
@synthesize label;
@end
