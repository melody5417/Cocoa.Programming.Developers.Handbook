#import <Cocoa/Cocoa.h>

@interface FormItemController : NSViewController {
	NSString *label;
}
@property (retain, nonatomic) NSString* label;
@end
