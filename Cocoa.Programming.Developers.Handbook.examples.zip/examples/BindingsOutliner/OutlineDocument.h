#import <Cocoa/Cocoa.h>
#import "OutlineItem.h"

@interface OutlineDocument : NSDocument {}
@end
