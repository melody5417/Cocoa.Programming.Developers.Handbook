#import "FormInterface.h"
#import <Cocoa/Cocoa.h>

@interface FormTest : NSObject {
	id<DynamicForm>form;
}

@end
