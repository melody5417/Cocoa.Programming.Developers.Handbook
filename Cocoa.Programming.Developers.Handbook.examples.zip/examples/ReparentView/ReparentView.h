#import <Cocoa/Cocoa.h>

@interface ReparentView : NSObject {
}
- (IBAction) reparentView: (id)sender;
@end
