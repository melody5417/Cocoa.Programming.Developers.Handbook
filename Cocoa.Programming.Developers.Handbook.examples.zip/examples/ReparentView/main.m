//
//  main.m
//  ReparentView
//
//  Created by Cocoa Programming on 14/02/2009.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
