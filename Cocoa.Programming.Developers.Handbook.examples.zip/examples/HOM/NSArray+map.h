#include <Foundation/Foundation.h>

@interface NSArray (AllElements)
- (id) map;
@end
