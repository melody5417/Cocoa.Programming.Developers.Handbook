#import <Foundation/Foundation.h>

@interface Fibonacci : NSObject {}
- (NSUInteger) fibonacci: (NSUInteger)i;
@end 
