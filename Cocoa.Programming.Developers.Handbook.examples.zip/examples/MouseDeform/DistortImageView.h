#import <Cocoa/Cocoa.h>

@interface DistortImageView : NSImageView {}
@end
