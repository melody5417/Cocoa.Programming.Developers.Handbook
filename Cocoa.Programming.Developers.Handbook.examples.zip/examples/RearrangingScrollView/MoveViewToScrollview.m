#import "MoveViewToScrollview.h"

@implementation MoveViewToScrollview
- (IBAction)MoveViewToScrollview: (id)sender
{
	[view addSubview: sender];
}
@end
