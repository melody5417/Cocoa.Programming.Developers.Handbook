#import <Cocoa/Cocoa.h>

@interface RearrangingScrollView : NSView {
	double top;
}
@end
