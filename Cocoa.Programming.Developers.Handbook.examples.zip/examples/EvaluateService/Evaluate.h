#import <Cocoa/Cocoa.h>

@interface Evaluate : NSObject {
}
@end
