#import <Cocoa/Cocoa.h>
#import "Dialog.h"
@interface Greeting : NSObject {
	Dialog *dialog;
}
@end
