#import <Cocoa/Cocoa.h>

int main(void)
{
	NSBeep();
	sleep(1);
	return 0;
}
