#import <Cocoa/Cocoa.h>

@interface FileBrowserDelegate : NSObject {
	IBOutlet NSBrowser *browser;
}
@end
