#import <Cocoa/Cocoa.h>


@interface HelloView : NSView {
	NSCell *cell;
}

@end
