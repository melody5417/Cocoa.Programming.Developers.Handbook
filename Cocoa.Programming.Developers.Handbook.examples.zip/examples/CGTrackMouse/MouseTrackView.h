#import <Cocoa/Cocoa.h>

@interface MouseTrackView : NSView {
	NSMutableArray *points;
}
@end
