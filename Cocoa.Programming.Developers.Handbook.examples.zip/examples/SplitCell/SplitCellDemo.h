#import <Cocoa/Cocoa.h>


@interface SplitCellDemo : NSObject {
	IBOutlet NSArray *objects;
	IBOutlet NSTableColumn *column;
}
@end
