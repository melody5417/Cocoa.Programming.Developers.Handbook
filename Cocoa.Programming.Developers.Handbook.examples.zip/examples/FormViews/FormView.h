#import <Cocoa/Cocoa.h>

@interface FormView : NSView {
	double top;
}
@end
