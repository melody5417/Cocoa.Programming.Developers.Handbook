#import <Cocoa/Cocoa.h>

@interface CurveTextView : NSView {}

@end
