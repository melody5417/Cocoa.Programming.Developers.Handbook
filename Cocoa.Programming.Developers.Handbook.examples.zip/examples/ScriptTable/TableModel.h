#import <Cocoa/Cocoa.h>

@interface TableModel : NSObject {
	NSMutableArray *items;
}
@end
