#import <Cocoa/Cocoa.h>
#import "TableModel.h"

@interface AppDelegate : NSObject {
	IBOutlet TableModel *model;
}
@end
