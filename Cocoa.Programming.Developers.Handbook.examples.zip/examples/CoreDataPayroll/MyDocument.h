#import <Cocoa/Cocoa.h>

@interface MyDocument : NSPersistentDocument {}
@end
