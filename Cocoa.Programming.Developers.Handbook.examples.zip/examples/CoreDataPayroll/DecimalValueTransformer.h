#import <Cocoa/Cocoa.h>

@interface DecimalValueTransformer : NSValueTransformer {}
@end
