#import "MyDocument.h"

@implementation MyDocument
- (NSString *)windowNibName 
{
    return @"MyDocument";
}
@end
