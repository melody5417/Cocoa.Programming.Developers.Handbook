#import <Cocoa/Cocoa.h>


@interface BouncingWindowController : NSWindowController {
	CGFloat dy, dx;
}

@end
