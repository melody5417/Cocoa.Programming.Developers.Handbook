//
//  CircleTextView.h
//  CircleTextView
//
//  Created by Cocoa Programming on 25/01/2009.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface CircleTextView : NSView {

}

@end
