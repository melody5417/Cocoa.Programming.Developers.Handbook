#import <Cocoa/Cocoa.h>


@interface CircleTextLayer : NSObject {
	NSAttributedString *str;
	IBOutlet NSView *view;
}

@end
