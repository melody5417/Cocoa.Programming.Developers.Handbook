//
//  main.m
//  HTMLEditor
//
//  Created by Cocoa Programming on 24/02/2009.
//  Copyright __MyCompanyName__ 2009 . All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **) argv);
}
