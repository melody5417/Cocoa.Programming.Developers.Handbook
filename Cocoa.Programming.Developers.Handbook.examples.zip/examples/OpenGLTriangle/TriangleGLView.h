#import <Cocoa/Cocoa.h>

@interface TriangleGLView : NSOpenGLView {
}

@end
