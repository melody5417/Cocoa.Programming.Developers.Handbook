#import <Cocoa/Cocoa.h>

@interface ButtonAnimator : NSObject {}
- (IBAction)hideButton: (id)sender;
@end
