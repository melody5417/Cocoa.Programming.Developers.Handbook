#import <Cocoa/Cocoa.h>

@interface WheelLayout : NSTextContainer {
	int holeSize;
}
@property int holeSize;
@end
