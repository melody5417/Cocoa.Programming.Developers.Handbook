@interface CircleTextCell : NSCell {
	CGFloat extraPadding;
}
- (void) setPadding:(CGFloat) aFloat;
- (CGFloat) padding;
@end
