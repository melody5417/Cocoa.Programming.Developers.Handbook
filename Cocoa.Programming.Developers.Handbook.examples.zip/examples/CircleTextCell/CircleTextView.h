#import <Cocoa/Cocoa.h>
@class CircleTextCell;

@interface CircleTextView : NSView {
	CircleTextCell *cell;
}

@end
