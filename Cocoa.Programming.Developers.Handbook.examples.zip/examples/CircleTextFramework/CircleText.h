#import <InterfaceBuilderKit/InterfaceBuilderKit.h>

@interface CircleText : IBPlugin {

}

@end
