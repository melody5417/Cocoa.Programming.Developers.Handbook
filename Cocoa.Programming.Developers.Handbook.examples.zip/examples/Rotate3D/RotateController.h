#import <Cocoa/Cocoa.h>

@interface RotateController : NSObject {}
- (IBAction)runRotate: (id)sender;
@end
